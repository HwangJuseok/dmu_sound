export const dummySongs = [
    { title: "노래 1", artist: "가수 A" },
    { title: "노래 2", artist: "가수 B" },
    { title: "노래 3", artist: "가수 C" },
    { title: "노래 4", artist: "가수 D" },
  ];

export const dummyChart = [
  { id: 1, title: "ETA", artist: "NewJeans" },
  { id: 2, title: "Super Shy", artist: "NewJeans" },
  { id: 3, title: "Seven", artist: "Jung Kook" },
  { id: 4, title: "Get a Guitar", artist: "RIIZE" },
  { id: 5, title: "Spicy", artist: "aespa" },
]